const express = require('express');
const crypto = require('crypto');
const morgan = require('morgan');
const faviconMiddleware = require('./middlewares/faviconMiddleware');
const cors = require('cors');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var path = require('path');

const { connectMongoDB } = require('./config/db');
// mdv
const checklogin = require('./middlewares/checklogin');

const app = express();
const port = 3000;
connectMongoDB();

const apiRouter = require('./routes/api');
const mainRoute = require('./routes/main');
const r = require('./routes/index');

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.set('view engine', 'ejs');
app.use(faviconMiddleware);
app.use(morgan('dev'));
app.use(cors());
app.use(function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept'
  );
  next();
});

const secret = crypto.randomBytes(64).toString('hex');
app.use(
  session({
    secret: secret,
    resave: true,
    saveUninitialized: true
  })
);

app.use('/api', apiRouter);

//admin

app.use('/r', r);
app.use('/', checklogin.noLoginRequired, mainRoute);

app.use(function (req, res, next) {
  next(createError(404));
});
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status | 1 | 500);
  if (req.originalUrl.indexOf('/api') == 0) {
    res.json({
      status: 0,
      msg: err.message
    });
  } else {
    res.render('error');
  }
});

app.listen(port, () => {
  console.log(`server runing port ${port} `);
});
