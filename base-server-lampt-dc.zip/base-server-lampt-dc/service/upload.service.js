const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const multer = require('multer');

/**
 * Cấu hình Cloudinary với thông tin từ biến môi trường.
 */
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME, // Tên cloud của Cloudinary.
  api_key: process.env.CLOUDINARY_API_KEY, // Khóa API của Cloudinary.
  api_secret: process.env.CLOUDINARY_API_SECRET // Bí mật API của Cloudinary.
});

/**
 * Cấu hình lưu trữ cho Multer sử dụng Cloudinary.
 */
const storage = new CloudinaryStorage({
  cloudinary: cloudinary, // Đối tượng Cloudinary đã cấu hình.
  params: {
    folder: 'uploads', // Thư mục lưu trữ trong Cloudinary.
    allowed_formats: ['jpg', 'png'] // Các định dạng hình ảnh được phép tải lên.
  }
});

/**
 * Tạo một đối tượng Multer với cấu hình lưu trữ Cloudinary.
 */
const upload = multer({ storage: storage }); // Đối tượng Multer để xử lý tệp tải lên.

module.exports = {
  upload
};


// nếu muốn lưu ảnh trong server sử dụng code này
// const multer = require('multer');
// const fs = require('fs');
// const path = require('path');

// // Đặt tên thư mục lưu trữ
// const uploadDir = 'uploads/';

// // Kiểm tra và tạo thư mục nếu chưa tồn tại
// if (!fs.existsSync(uploadDir)) {
//   fs.mkdirSync(uploadDir, { recursive: true }); // recursive:true tạo các thư mục con nếu cần
// }

// // Cấu hình lưu trữ multer
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     // Kiểm tra và tạo thư mục lưu trữ nếu chưa tồn tại
//     if (!fs.existsSync(uploadDir)) {
//       fs.mkdirSync(uploadDir, { recursive: true });
//     }
//     cb(null, uploadDir); // Đặt đường dẫn đến thư mục lưu trữ
//   },
//   filename: (req, file, cb) => {
//     // Tạo tên tệp tin mới để tránh đè tên tệp trùng nhau
//     const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
//     cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
//   }
// });

// // Bộ lọc để chỉ cho phép các định dạng ảnh nhất định
// const fileFilter = (req, file, cb) => {
//   const filetypes = /jpeg|jpg|png/;
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb(new Error('Chỉ cho phép các định dạng ảnh JPG và PNG!'));
//   }
// };

// // Tạo đối tượng multer với cấu hình đã định
// const upload = multer({
//   storage: storage,
//   fileFilter: fileFilter,
//   limits: { fileSize: 5 * 1024 * 1024 } // Giới hạn kích thước ảnh (5MB)
// });

// module.exports = {
//   upload
// };
