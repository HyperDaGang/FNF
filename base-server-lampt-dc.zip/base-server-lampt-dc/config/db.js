require('dotenv').config();
const { URI_DATABASE_MONGODB_ATLAS } = process.env;

const mongoose = require('mongoose');
const connectMongoDB = async () => {
  try {
    await mongoose.connect(URI_DATABASE_MONGODB_ATLAS);
    console.log('CONNECT MONGODB ATLAS SUCCESSFULLY');
  } catch (error) {
    console.log('ERROR CONNECT MONGODB ATLAS');
    console.log(error);
  }
};

module.exports = { connectMongoDB };
