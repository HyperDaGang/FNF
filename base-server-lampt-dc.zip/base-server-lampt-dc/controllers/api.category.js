var Category = require('../models/category.model');
const { responseHandler } = require('../utils/responseHandler');
const mongoose = require('mongoose');

const getAll = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;

    if (limit < 1) limit = 1;
    if (limit > 10) limit = 10;

    const skip = (page - 1) * limit;

    const { name } = req.query;
    const searchQuery = {};

    if (name) {
      searchQuery.name = new RegExp(name, 'i');
    }

    const list = await Category.find(searchQuery).skip(skip).limit(limit);

    const totalRecords = await Category.countDocuments();

    const pagination = {
      currentPage: page,
      totalPages: Math.ceil(totalRecords / limit),
      totalRecords: totalRecords,
      limit: limit
    };

    if (list.length > 0) {
      return responseHandler(res, 200, 'tìm thành công', {
        data: list,
        ...pagination
      });
    } else {
      return responseHandler(res, 404, 'không có dữ liệu phù hợp');
    }
  } catch (error) {
    return responseHandler(res, 500, 'lỗi', null, error.message);
  }
};
const getById = async (req, res, next) => {
  const id = req.params.id;
  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return responseHandler(res, 400, 'id không hợp lệ');
    }

    const data = await Category.findById(id);
    if (data) {
      return responseHandler(res, 200, 'tìm thành công', data);
    } else {
      return responseHandler(res, 404, 'không có dữ liệu phù hợp');
    }
  } catch (error) {
    return responseHandler(res, 500, 'lỗi', null, error.message);
  }
};

module.exports = {
  getAll,
  getById
};
