const mVoucher = require('../models/voucher.model');
const { responseHandler } = require('../utils/responseHandler');
const cron = require('node-cron');

cron.schedule('* * * * *', async () => {
  const currentTime = Date.now();
  try {
    await Promise.all([
      mVoucher.updateMany(
        { status: 'Active', endDate: { $lt: currentTime } },
        { status: 'Expired' }
      ),
      mVoucher.updateMany(
        {
          status: 'Inactive',
          startDate: { $lt: currentTime },
          endDate: { $gt: currentTime }
        },
        { status: 'Active' }
      )
    ]);

    console.log('Updated expired vouchers.');
  } catch (error) {
    console.error('Error updating vouchers:', error.message);
  }
});

// const getAll = async (req, res, next) => {
//   try {
//     const currentDate = Date.now();
//     const filter = { status: 'Active' };

//     let list = await mVoucher.find(filter);

//     const expiredUpdates = list
//       .filter((element) => element.endDate < currentDate)
//       .map((element) =>
//         mVoucher.updateOne({ _id: element._id }, { status: 'Expired' })
//       );

//     if (expiredUpdates.length > 0) {
//       await Promise.all(expiredUpdates);

//       list = await mVoucher.find(filter);
//     }

//     if (list.length > 0) {
//       return responseHandler(res, 200, 'Tìm thành công', list);
//     } else {
//       return responseHandler(res, 400, 'không có dữ liệu phù hợp');
//     }
//   } catch (error) {
//     return responseHandler(res, 500, 'Lỗi', null, error.message);
//   }
// };

const getAll = async (req, res, next) => {
  try {
    const list = await mVoucher.find({}).sort({ status: 1 });

    if (list.length > 0) {
      return responseHandler(res, 200, 'tìm thành công', list);
    }

    return responseHandler(res, 400, 'không có dữ liệu phù hợp');
  } catch (error) {
    return responseHandler(res, 500, 'lỗi', null, error.message);
  }
};

module.exports = {
  getAll
};
