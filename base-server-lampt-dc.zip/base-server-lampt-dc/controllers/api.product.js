const mProduct = require('../models/product.model');
const mProductR = require('../models/productReview.model');
const mProductF = require('../models/productFavorites.model');
const mongoose = require('mongoose');
const { responseHandler } = require('../utils/responseHandler');

var objReturn = {
  status: 1,
  msg: 'OK'
};

const getAll = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;

    if (limit < 1) limit = 1;
    if (limit > 10) limit = 10;

    const skip = (page - 1) * limit;

    const { name, priceMin, priceMax, sort, order } = req.query;
    const searchQuery = {};

    if (name) {
      searchQuery.name = new RegExp(name, 'i');
    }
    if (priceMin || priceMax) {
      searchQuery.price = {};
      if (priceMin) searchQuery.price.$gte = parseFloat(priceMin);
      if (priceMax) searchQuery.price.$lte = parseFloat(priceMax);
    }

    const sortOptions = {};
    if (sort) {
      sortOptions[sort] = order === 'desc' ? -1 : 1; // 'desc' => giảm dần, mặc định tăng dần
    }
    // sort=name or price: Trường sắp xếp
    // order=asc: Tăng dần
    // order=desc: Giảm dần

    const [data, totalRecords] = await Promise.all([
      mProduct
        .find(searchQuery)
        .populate('categorysId')
        .sort(sortOptions)
        .skip(skip)
        .limit(limit),
      mProduct.countDocuments()
    ]);

    const convertData = await Promise.all(
      data.map(async (item) => {
        const [favoritesValue, reviewCount, dataPR] = await Promise.all([
          mProductF.countDocuments({ productId: item._id }),
          mProductR.countDocuments({ productId: item._id }),
          mProductR.find({ productId: item._id })
        ]);

        // Tính giá trị trung bình của rating
        const totalRating = dataPR.reduce(
          (sum, review) => sum + (review.rating || 0),
          0
        );
        let reviewValue = reviewCount > 0 ? totalRating / reviewCount : 0;
        // Làm tròn reviewValue tới 1 chữ số sau dấu thập phân
        reviewValue = Math.round(reviewValue * 10) / 10;

        return {
          ...item.toObject(),
          favoritesValue,
          reviewValue,
          reviewCount
        };
      })
    );

    const pagination = {
      currentPage: page,
      totalPages: Math.ceil(totalRecords / limit),
      totalRecords: totalRecords,
      limit: limit
    };
    if (data.length > 0) {
      return responseHandler(res, 200, 'tìm thành công', {
        data: convertData,
        ...pagination
      });
    } else {
      return responseHandler(res, 400, 'không tìm thấy dữ liệu');
    }
  } catch (error) {
    return responseHandler(res, 500, 'lỗi', null, error.message);
  }
};

const getById = async (req, res, next) => {
  try {
    const productId = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
      return responseHandler(res, 400, 'id không hợp lệ');
    }

    const product = await mProduct.findById(productId).populate('categorysId');
    if (!product) {
      return responseHandler(res, 404, 'sản phẩm không tồn tại');
    }

    const [favoritesValue, reviews] = await Promise.all([
      mProductF.countDocuments({ productId }),
      mProductR.find({ productId })
    ]);

    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
    const reviewCount = reviews.length;
    const reviewValue =
      reviewCount > 0 ? Math.round((totalRating / reviewCount) * 10) / 10 : 0;

    const productWithStats = {
      ...product.toObject(),
      favoritesValue,
      reviewValue,
      reviewCount
    };

    return responseHandler(res, 200, 'tìm thành công', productWithStats);
  } catch (error) {
    return responseHandler(res, 500, 'lỗi', null, error.message);
  }
};

const create = async (req, res, next) => {
  objReturn.data = null;

  const {
    CategoryID,
    Description,
    Price,
    ProductName,
    StockQuantity,
    species,
    importPrice
  } = req.body;
  try {
    if (
      !CategoryID ||
      !Description ||
      !Price ||
      !ProductName ||
      !StockQuantity ||
      !species ||
      !importPrice
    ) {
      objReturn.status = 0;
      objReturn.msg = 'hãy nhập đủ';
      return res.status(400).json(objReturn);
    }

    if (!req.file && !req.file.path) {
      objReturn.status = 0;
      objReturn.msg = 'thiếu ảnh';
      return res.status(400).json(objReturn);
    }

    const product = new mProduct({
      CategoryID,
      Description,
      Price,
      ProductName,
      StockQuantity,
      importPrice,
      Image: req.file.path,
      species
    });

    const savedProduct = await product.save();
    objReturn.msg = 'tạo thành công';
    objReturn.data = savedProduct;
  } catch (error) {
    objReturn.status = 0;
    objReturn.msg = error.message;
    return res.status(500).json(objReturn);
  }
  res.status(200).json(objReturn);
};
const updateById = async (req, res, next) => {
  const { productId } = req.params;
  const {
    CategoryID,
    Description,
    Price,
    ProductName,
    StockQuantity,
    species,
    importPrice
  } = req.body;

  if (!req.file && !req.file.path) {
    objReturn.status = 0;
    objReturn.msg = 'thiếu ảnh';
    return res.status(400).json(objReturn);
  }

  try {
    const updatedProduct = await mProduct.findByIdAndUpdate(
      productId,
      {
        CategoryID,
        Description,
        Price,
        ProductName,
        StockQuantity,
        species,
        Image: req.file.path ? req.file.path : updatedProduct.Image,
        importPrice
      },
      { new: true }
    );

    if (!updatedProduct) {
      objReturn.status = 0;
      objReturn.msg = 'Product not found';
      return res.status(404).json(objReturn);
    }

    objReturn.msg = 'Update successful';
    objReturn.data = updatedProduct;
  } catch (error) {
    objReturn.status = 0;
    objReturn.msg = error.message;
    return res.status(500).json(objReturn);
  }

  res.json(objReturn);
};

const deleteById = async (req, res, next) => {
  const { productId } = req.params;

  try {
    const deletedProduct = await mProduct.findByIdAndDelete(productId);

    if (!deletedProduct) {
      objReturn.status = 0;
      objReturn.msg = 'Product not found';
      return res.status(404).json(objReturn);
    }

    objReturn.msg = 'Delete successful';
    objReturn.data = deletedProduct;
  } catch (error) {
    objReturn.status = 0;
    objReturn.msg = error.message;
    return res.status(500).json(objReturn);
  }

  res.json(objReturn);
};

module.exports = {
  getAll,
  getById,
  //admin
  create,
  updateById,
  deleteById
};
