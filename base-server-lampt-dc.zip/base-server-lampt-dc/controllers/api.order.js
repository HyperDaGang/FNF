let dateFormat = require('date-format');
let moment = require('moment');
var config = require('../config/vnpay-config');
//==
const mongoose = require('mongoose');
let mdOrder = require('../models/order.model');
let mdPaymentMethod = require('../models/paymentMethod.model');
let mdProduct = require('../models/product.model');
let mdCart = require('../models/cart.model');
let mdUser = require('../models/user.model');
let mdVoucher = require('../models/voucher.model');
const { responseHandler } = require('../utils/responseHandler');

var objReturn = {
  status: 1,
  msg: 'OK'
};

// Function to sort an object by its keys
/**
 * @param {Object} obj - The object to be sorted
 * @returns {Object} - The sorted object
 */
function sortObject(obj) {
  // Create an empty object to store the sorted keys and values
  let sorted = {};
  // Create an empty array to store the sorted keys
  let str = [];
  // Variable to store the current key
  let key;

  // Iterate over the object's keys
  for (key in obj) {
    // Check if the key belongs to the object itself
    if (obj.hasOwnProperty(key)) {
      // Push the encoded key to the array
      str.push(encodeURIComponent(key));
    }
  }

  // Sort the array of encoded keys
  str.sort();

  // Iterate over the sorted keys
  for (key = 0; key < str.length; key++) {
    // Assign the encoded value to the sorted object, replacing %20 with +
    sorted[str[key]] = encodeURIComponent(obj[str[key]]).replace(/%20/g, '+');
  }

  // Return the sorted object
  return sorted;
}

let globalCartID;
let globalUserID;
let globalAmount;
let globalVoucherID;
let globalPaymentMethodID;

/**
 * This function creates a VNPay payment URL and returns it to the client.
 *
 * @param {Object} req - The request object
 * @param {Object} res - The response object
 * @param {Function} next - The next middleware function
 * @returns {Object} - The payment URL and other information
 */
const createPaymentUrl = async (req, res, next) => {
  // Extract the IP address from the request headers
  var ipAddr =
    req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;

  // Extract the necessary configuration values
  var tmnCode = config.vnp_TmnCode;
  var secretKey = config.vnp_HashSecret;
  var vnpUrl = config.vnp_Url;
  var returnUrl = config.vnp_ReturnUrl;

  // Create a new date object and format it as a string
  var date = new Date();
  let createDate = moment(date).format('YYYYMMDDHHmmss');
  var orderId = dateFormat(date, 'HHmmss');

  // Extract the user ID and cart ID from the request parameters and body
  let userID = req.body.userId;
  let cartID = req.body.cartId;
  let paymentMethodID = req.body.paymentMethodId;
  let voucherId = req.body.voucherId;
  let amount = 0;

  try {
    // Validate the user ID
    if (!mongoose.Types.ObjectId.isValid(userID)) {
      return responseHandler(res, 400, 'iduser không hợp lệ');

    }
    // Validate the voucherId
    if (!mongoose.Types.ObjectId.isValid(voucherId) && voucherId !== '') {
      return responseHandler(res, 400, 'voucherId không hợp lệ');

    }

    // Validate the paymentMethodID
    if (!mongoose.Types.ObjectId.isValid(paymentMethodID)) {
      return responseHandler(res, 400, 'paymentMethodID không hợp lệ');
    }


    // Find the user by ID
    const finPaymentMethod = await mdPaymentMethod.findById(paymentMethodID);
    if (!finPaymentMethod) {

      return responseHandler(res, 400, 'Không tìm thấy phương thức thanh toán');

    }
    // Find voucher
    const finVoucher = await mdVoucher.findById(voucherId);
    if (finVoucher) {
      if (finVoucher.status !== 'Active' || finVoucher.usageLimit <= 0) {
        return responseHandler(res, 400, 'voucher đã hết hạn hoặc số lượng đã được dùng hết');
      }
    }

    if (finPaymentMethod.code !== 'VNPAY') {

      return responseHandler(res, 400, 'Phương thước thanh toán không hợp lệ');

    }

    const finUser = await mdUser.findById(userID);

    // Validate the cart ID and user
    if (!cartID || !Array.isArray(cartID) || !finUser) {

      return responseHandler(res, 400, 'Dữ liệu giỏ hàng hoặc user không hợp lệ');

    }

    // Validate and calculate the amount for each cart item
    for (const itemCart of cartID) {
      if (!mongoose.Types.ObjectId.isValid(itemCart)) {
        return responseHandler(res, 400, 'idcart không hợp lệ');

      }

      const fincart = await mdCart.findById(itemCart);
      if (!fincart) {

        return responseHandler(res, 400, 'Không tìm thấy sản phẩm trong giỏ hàng');

      }
      const findProduct = await mdProduct.findById(fincart.productId);
      if (
        findProduct.quantity <= 0 &&
        fincart.quantity > findProduct.quantity
      ) {

        return responseHandler(res, 400, 'số lượng sản phẩm đã hết hoặc không đủ');

      }

      amount +=
        fincart.quantity * findProduct.price -
        fincart.quantity * findProduct.discount;

    }
    amount -= finVoucher.discountValue;
  } catch (error) {

    return responseHandler(res, 500, 'lỗi', null, error.message);

  }

  // Store the global variables
  globalCartID = cartID;
  globalAmount = amount;
  globalUserID = userID;
  globalVoucherID = voucherId;
  globalPaymentMethodID = paymentMethodID;

  // Set the locale to 'vn' if it is not provided
  let locale = req.body.language;
  if (locale === null || locale === '' || locale === undefined) {
    locale = 'vn';
  }

  // Set the currency code to 'VND'
  var currCode = 'VND';

  // Create the VNPay parameters
  var vnp_Params = {};
  vnp_Params['vnp_Version'] = '2.1.0';
  vnp_Params['vnp_Command'] = 'pay';
  vnp_Params['vnp_TmnCode'] = tmnCode;
  vnp_Params['vnp_Locale'] = locale;
  vnp_Params['vnp_CurrCode'] = currCode;
  vnp_Params['vnp_TxnRef'] = orderId;
  vnp_Params['vnp_OrderInfo'] = 'Thanh toan cho ma GD:' + orderId;
  vnp_Params['vnp_OrderType'] = 'other';
  vnp_Params['vnp_Amount'] = amount * 100;
  vnp_Params['vnp_ReturnUrl'] = returnUrl;
  vnp_Params['vnp_IpAddr'] = ipAddr;
  vnp_Params['vnp_CreateDate'] = createDate;

  // Sort and sign the parameters
  vnp_Params = sortObject(vnp_Params);
  var querystring = require('qs');
  var signData = querystring.stringify(vnp_Params, { encode: false });
  var crypto = require('crypto');
  var hmac = crypto.createHmac('sha512', secretKey);
  var signed = hmac.update(new Buffer.from(signData, 'utf-8')).digest('hex');
  vnp_Params['vnp_SecureHash'] = signed;

  // Construct the payment URL
  vnpUrl += '?' + querystring.stringify(vnp_Params, { encode: false });

  // Return the payment URL to the client

  return responseHandler(res, 200, 'OK', vnpUrl, null, 'url');

};

/**
 * This function handles the return from the VNPay payment gateway.
 * It validates the parameters, updates the order and cart data,
 * and renders a success page or an error page.
 *
 * @param {Object} req - The request object
 * @param {Object} res - The response object
 * @param {Function} next - The next middleware function
 * @returns {Object} - The success page or an error page
 */
const vnpayReturn = async (req, res, next) => {
  // Extract the VNPay parameters from the request query

  let vnp_Params = req.query;

  // Extract the secure hash from the parameters and delete it
  let secureHash = vnp_Params['vnp_SecureHash'];
  delete vnp_Params['vnp_SecureHash'];
  delete vnp_Params['vnp_SecureHashType'];

  // Sort and sign the parameters
  vnp_Params = sortObject(vnp_Params);
  // let config = require('config');
  let tmnCode = config.vnp_TmnCode;
  let secretKey = config.vnp_HashSecret;

  let querystring = require('qs');
  let signData = querystring.stringify(vnp_Params, { encode: false });
  let crypto = require('crypto');
  let hmac = crypto.createHmac('sha512', secretKey);
  let signed = hmac.update(new Buffer.from(signData, 'utf-8')).digest('hex');

  // Validate the secure hash
  if (secureHash === signed) {
    try {
      // Extract the global variables
      const userID = globalUserID;
      const cartID = globalCartID;
      const amount = globalAmount;
      const voucher = globalVoucherID;

      // Check the quantity of each product in the cart
      for (const iterator of cartID) {
        const finCart = await mdCart.findById(iterator);
        const findProduct = await mdProduct.findById(finCart.productId);

        const quantityCart = finCart.quantity;
        const quantityProduct = findProduct.quantity;

        if (quantityCart > quantityProduct) {
          res.render('order/success', {
            code: 'Không thể thực hiện ,do số lượng sản phẩm nào đó không đủ hoặc đã hết'
          });
        } else {
        }
      }
      await mdVoucher.updateOne({ _id: voucher }, { $inc: { usageLimit: -1 } });

      // Construct the cart data
      let data_cart = [];
      for (const iterator of cartID) {
        const finCart = await mdCart
          .findById(iterator)
          .populate('userId')
          .populate('productId');

        try {
          var cartObject = {
            _id: finCart._id,
            userId: {
              _id: finCart.userId._id,
              name: finCart.userId.name,
              email: finCart.userId.email,
              phone: finCart.userId.phone
            },
            productId: {
              _id: finCart.productId._id,
              categorysId: {
                _id: finCart.productId.categorysId._id,
                name: finCart.productId.categorysId.name
              },
              description: finCart.productId.description,
              price: finCart.productId.price,
              name: finCart.productId.name,
              discount: finCart.productId.discount,
              image: finCart.productId.image,
              quantity: finCart.productId.quantity
            },
            quantity: finCart.quantity,
            __v: finCart.__v
          };
        } catch (error) {
        }

        data_cart.push(cartObject);
      }

      // Construct the order data
      const newOrderData = {
        userId: userID,
        cartId: cartID,
        cartData: data_cart,
        totalAmount: amount,
        voucherId: voucher,
        paymentMethodId: globalPaymentMethodID
      };

      // Save the order and order detail data
      const newORDER = new mdOrder(newOrderData);
      await newORDER.save();

      // Update the product and cart data
      for (const iterator of cartID) {
        const finCart = await mdCart.findById(iterator);
        const findProduct = await mdProduct.findById(finCart.productId);

        let quantityCart = finCart.quantity;
        let quantityProduct = findProduct.quantity;

        try {
          quantityProduct -= quantityCart;
          await mdProduct.findByIdAndUpdate(
            finCart.productId,
            { quantity: quantityProduct },
            { new: true }
          );
          await mdCart.findByIdAndDelete(cartID);
        } catch (error) {
          return responseHandler(res, 500, 'lỗi', null, error.message);

        }
      }

      // Render the success page
      res.render('order/success', {
        code: vnp_Params['vnp_ResponseCode']
      });
    } catch (error) {
      return responseHandler(res, 500, 'lỗi', null, error.message);
    }
  } else {
    return res.status(400).json({ error: 'Đã xảy ra lỗi 2 ' });
  }
};

/**
 * This function is responsible for fetching all orders associated with a user from the database
 * based on the userID in the request parameters.
 * It uses the orderModel from the mdOrder module to perform the query.
 * The query is populated with the userId field to include their respective data.
 * The function then checks if the order list has any items.
 * If it does, it sets the status to 1, the message to 'tìm thành công', and the data to the list of orders.
 * If it doesn't, it sets the status to 0, the message to 'Không tìm thấy đơn hàng',
 * and returns a JSON response with the status and message.
 * If there is an error during the process, it sets the status to 0, the message to the error message,
 * and returns a JSON response with the status and message.
 * Finally, it returns a JSON response with the status, message, and data.
 *
 * @param {Object} req - The request object
 * @param {Object} res - The response object
 * @param {Function} next - The next middleware function
 * @return {Object} - A JSON response with the status, message, and data
 */
const getByIdUser = async (req, res, next) => {
  objReturn.data = null;

  try {
    const userID = req.params.id;

    // Check if the userID is valid
    if (!mongoose.Types.ObjectId.isValid(userID)) {
      objReturn.status = 0; // Set the status to 0
      objReturn.msg = 'userID không hợp lệ'; // Set the message to 'userID không hợp lệ'
      return res.status(400).json(objReturn); // Return a JSON response with the status and message
    }

    // Query the orderModel to find all orders associated with the user by userID
    const order = await mdOrder
      .find({ userId: userID })
      .populate('userId') // Populate the userId field with the respective data
      .populate('voucherId')
      .populate('paymentMethodId');

    // Check if the order list has any items
    if (order.length <= 0) {
      // Check if the order list has any items
      objReturn.status = 0; // Set the status to 0
      objReturn.msg = 'Không tìm thấy đơn hàng'; // Set the message to 'Không tìm thấy đơn hàng'
      return res.status(400).json(objReturn); // Return a JSON response with the status and message
    } else {
      objReturn.status = 1; // Set the status to 1
      objReturn.msg = 'tìm thành công'; // Set the message to 'tìm thành công'
      objReturn.data = order; // Set the data to the order list
    }
  } catch (error) {
    objReturn.status = 0; // Set the status to 0
    objReturn.msg = error.message; // Set the message to the error message
    return res.status(500).json(objReturn); // Return a JSON response with the status and message
  }

  res.json(objReturn);
};

module.exports = { createPaymentUrl, vnpayReturn, getByIdUser };
